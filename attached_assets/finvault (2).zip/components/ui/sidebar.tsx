"use client"

import * as React from "react"
import { useIsMobile } from "@/hooks/use-mobile"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { Sheet, SheetContent } from "@/components/ui/sheet"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { PanelLeft } from "lucide-react"

const SidebarContext = React.createContext<{
  expanded: boolean
  setExpanded: React.Dispatch<React.SetStateAction<boolean>>
  mobileOpen: boolean
  setMobileOpen: React.Dispatch<React.SetStateAction<boolean>>
} | null>(null)

export function useSidebar() {
  const context = React.useContext(SidebarContext)
  if (!context) {
    throw new Error("useSidebar must be used within a SidebarProvider")
  }
  return context
}

interface SidebarProviderProps {
  children: React.ReactNode
  defaultExpanded?: boolean
}

export function SidebarProvider({ children, defaultExpanded = true }: SidebarProviderProps) {
  const [expanded, setExpanded] = React.useState(defaultExpanded)
  const [mobileOpen, setMobileOpen] = React.useState(false)

  return (
    <SidebarContext.Provider value={{ expanded, setExpanded, mobileOpen, setMobileOpen }}>
      {children}
    </SidebarContext.Provider>
  )
}

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode
}

export function Sidebar({ children, className, ...props }: SidebarProps) {
  const { expanded, setExpanded, mobileOpen, setMobileOpen } = useSidebar()
  const isMobile = useIsMobile()

  if (isMobile) {
    return (
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="w-[300px] p-0">
          <div className="flex h-full flex-col overflow-hidden">{children}</div>
        </SheetContent>
      </Sheet>
    )
  }

  return (
    <div
      data-expanded={expanded}
      className={cn(
        "relative h-screen border-r bg-background transition-all duration-300 ease-in-out",
        expanded ? "w-[280px]" : "w-[80px]",
        className,
      )}
      {...props}
    >
      <div className="flex h-full flex-col overflow-hidden">{children}</div>
    </div>
  )
}

interface SidebarHeaderProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode
}

export function SidebarHeader({ children, className, ...props }: SidebarHeaderProps) {
  return (
    <div className={cn("flex h-14 items-center border-b px-4", className)} {...props}>
      {children}
    </div>
  )
}

interface SidebarMainProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode
}

export function SidebarMain({ children, className, ...props }: SidebarMainProps) {
  return (
    <div className={cn("flex-1 overflow-auto", className)} {...props}>
      {children}
    </div>
  )
}

interface SidebarFooterProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode
}

export function SidebarFooter({ children, className, ...props }: SidebarFooterProps) {
  return (
    <div className={cn("flex items-center border-t p-4", className)} {...props}>
      {children}
    </div>
  )
}

interface SidebarNavProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode
}

export function SidebarNav({ children, className, ...props }: SidebarNavProps) {
  return (
    <div className={cn("flex flex-col gap-2 p-2", className)} {...props}>
      {children}
    </div>
  )
}

interface SidebarNavItemProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  children?: React.ReactNode
  title: string
  icon: React.ReactNode
  isActive?: boolean
}

export function SidebarNavItem({ children, title, icon, isActive, className, ...props }: SidebarNavItemProps) {
  const { expanded } = useSidebar()

  return (
    <TooltipProvider>
      <Tooltip delayDuration={0}>
        <TooltipTrigger asChild>
          <a
            className={cn(
              "flex h-10 items-center gap-2 rounded-md px-3 text-muted-foreground hover:bg-muted hover:text-foreground",
              isActive && "bg-muted font-medium text-foreground",
              className,
            )}
            {...props}
          >
            {icon}
            {expanded && <span>{title}</span>}
          </a>
        </TooltipTrigger>
        {!expanded && <TooltipContent side="right">{title}</TooltipContent>}
      </Tooltip>
    </TooltipProvider>
  )
}

interface SidebarTriggerProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {}

export function SidebarTrigger({ className, ...props }: SidebarTriggerProps) {
  const { expanded, setExpanded, setMobileOpen } = useSidebar()
  const isMobile = useIsMobile()

  return (
    <Button
      variant="ghost"
      size="icon"
      className={cn("h-9 w-9", className)}
      onClick={() => {
        if (isMobile) {
          setMobileOpen(true)
        } else {
          setExpanded(!expanded)
        }
      }}
      {...props}
    >
      <PanelLeft className="h-5 w-5" />
      <span className="sr-only">Toggle Sidebar</span>
    </Button>
  )
}

interface SidebarSectionProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode
  title?: string
}

export function SidebarSection({ children, title, className, ...props }: SidebarSectionProps) {
  const { expanded } = useSidebar()

  return (
    <div className={cn("py-2", className)} {...props}>
      {title && expanded && (
        <div className="mb-2 px-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground">{title}</div>
      )}
      {children}
    </div>
  )
}

interface SidebarSearchProps extends React.InputHTMLAttributes<HTMLInputElement> {}

export function SidebarSearch({ className, ...props }: SidebarSearchProps) {
  const { expanded } = useSidebar()

  if (!expanded) {
    return null
  }

  return (
    <div className="px-2 py-2">
      <Input className={cn("h-9", className)} placeholder="Search..." {...props} />
    </div>
  )
}

export function SidebarSeparator() {
  return <Separator className="my-2" />
}
