"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ComparisonChart } from "@/components/compare/comparison-chart"

export default function ComparePage() {
  return (
    <div className="flex flex-col gap-4">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Financial Comparison</h2>
        <p className="text-muted-foreground">Compare your finances with benchmarks or peers</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Financial Comparison Tool</CardTitle>
          <CardDescription>
            Compare your financial position with benchmarks or peers to see where you stand
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ComparisonChart />
        </CardContent>
      </Card>
    </div>
  )
}
