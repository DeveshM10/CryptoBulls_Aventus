"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PlusCircle, Download, Filter, ArrowUpRight, Calendar, Search, Trash2 } from "lucide-react"
import { AddExpenseForm } from "@/components/budget/add-expense-form"
import { AddIncomeForm } from "@/components/budget/add-income-form"
import { AddDailyExpenseForm } from "@/components/budget/add-daily-expense-form"
import { useFinanceStore } from "@/components/store/finance-store"
import { BudgetChart } from "@/components/budget/budget-chart"
import { ExpenseByCategoryChart } from "@/components/budget/expense-by-category-chart"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"

function BudgetCategoryCard({ title, budgeted, spent, percentage, status }) {
  let statusColor = "bg-emerald-500"
  if (status === "warning") statusColor = "bg-amber-500"
  if (status === "danger") statusColor = "bg-rose-500"

  return (
    <Card className="overflow-hidden border bg-card text-card-foreground shadow-sm hover:shadow-md transition-shadow">
      <CardContent className="p-0">
        <div className="flex flex-col p-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-lg font-semibold">{title}</h3>
            <div className="text-sm font-medium">
              {spent} / {budgeted}
            </div>
          </div>
          <Progress value={percentage} className="h-2" indicatorClassName={statusColor} />
          <div className="flex justify-between mt-2">
            <p className="text-xs text-muted-foreground">Budget used</p>
            <p
              className={`text-xs font-medium ${
                status === "danger"
                  ? "text-rose-500"
                  : status === "warning"
                    ? "text-amber-500"
                    : "text-muted-foreground"
              }`}
            >
              {percentage}%
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default function BudgetPage() {
  const {
    expenses,
    addExpense,
    incomes,
    addIncome,
    dailyExpenses,
    addDailyExpense,
    deleteDailyExpense,
    getTotalIncome,
    getTotalExpenses,
    getSurplus,
  } = useFinanceStore()

  const [activeTab, setActiveTab] = useState("budget")
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")

  // Calculate monthly change percentages
  // In a real app, this would be calculated from historical data
  const incomeChangePercent = "+5.2%"
  const expensesChangePercent = "+2.8%"
  const surplusChangePercent = "+12.5%"

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value)
  }

  // Filter daily expenses based on search and category
  const filteredDailyExpenses = dailyExpenses.filter((expense) => {
    const matchesSearch =
      expense.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      expense.notes?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || expense.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  // Get unique categories from daily expenses
  const expenseCategories = ["all", ...new Set(dailyExpenses.map((expense) => expense.category))]

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Budget & Expenses</h2>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          {activeTab === "budget" ? (
            <AddExpenseForm onAddExpense={addExpense} />
          ) : activeTab === "income" ? (
            <AddIncomeForm onAddIncome={addIncome} />
          ) : (
            <AddDailyExpenseForm onAddExpense={addDailyExpense} />
          )}
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="overflow-hidden border bg-card text-card-foreground shadow-sm hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Monthly Income</CardTitle>
            <CardDescription>Total income for this month</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(getTotalIncome())}</div>
            <p className="text-xs text-muted-foreground mt-2 flex items-center">
              <span className="text-emerald-500 inline-flex items-center">
                <ArrowUpRight className="mr-1 h-4 w-4" />
                {incomeChangePercent}
              </span>{" "}
              from last month
            </p>
          </CardContent>
        </Card>

        <Card className="overflow-hidden border bg-card text-card-foreground shadow-sm hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Monthly Expenses</CardTitle>
            <CardDescription>Total expenses for this month</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(getTotalExpenses())}</div>
            <p className="text-xs text-muted-foreground mt-2 flex items-center">
              <span className="text-rose-500 inline-flex items-center">
                <ArrowUpRight className="mr-1 h-4 w-4" />
                {expensesChangePercent}
              </span>{" "}
              from last month
            </p>
          </CardContent>
        </Card>

        <Card className="overflow-hidden border bg-card text-card-foreground shadow-sm hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Monthly Surplus</CardTitle>
            <CardDescription>Available for savings or investments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(getSurplus())}</div>
            <p className="text-xs text-muted-foreground mt-2 flex items-center">
              <span className="text-emerald-500 inline-flex items-center">
                <ArrowUpRight className="mr-1 h-4 w-4" />
                {surplusChangePercent}
              </span>{" "}
              from last month
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="budget" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full md:w-auto grid-cols-3 h-auto md:h-10">
          <TabsTrigger
            value="budget"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Budget
          </TabsTrigger>
          <TabsTrigger
            value="income"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Income
          </TabsTrigger>
          <TabsTrigger
            value="expenses"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            Daily Expenses
          </TabsTrigger>
        </TabsList>

        <TabsContent value="budget" className="space-y-4">
          {/* Budget Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Budget vs. Actual Spending</CardTitle>
              <CardDescription>Compare your budgeted amounts with actual spending</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <BudgetChart expenses={expenses} />
            </CardContent>
          </Card>

          <div className="grid gap-4">
            {expenses.map((expense) => (
              <BudgetCategoryCard
                key={expense.id}
                title={expense.title}
                budgeted={expense.budgeted}
                spent={expense.spent}
                percentage={expense.percentage}
                status={expense.status}
              />
            ))}

            <Card
              className="border border-dashed flex items-center justify-center h-[100px] bg-muted/20 hover:bg-muted/40 transition-colors cursor-pointer"
              onClick={() => document.getElementById("add-expense-trigger")?.click()}
            >
              <div className="flex flex-col items-center gap-2 text-muted-foreground">
                <PlusCircle className="h-8 w-8" />
                <p>Add Budget Category</p>
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="income" className="space-y-4">
          <div className="grid gap-4">
            {incomes.map((income) => (
              <Card
                key={income.id}
                className="overflow-hidden border bg-card text-card-foreground shadow-sm hover:shadow-md transition-shadow"
              >
                <CardContent className="p-0">
                  <div className="flex flex-col md:flex-row md:items-center p-4">
                    <div className="flex-1 space-y-1 mb-4 md:mb-0">
                      <h3 className="text-lg font-semibold">{income.title}</h3>
                      <p className="text-sm text-muted-foreground">{income.description}</p>
                    </div>
                    <div className="text-xl font-bold">{income.amount}</div>
                  </div>
                </CardContent>
              </Card>
            ))}

            <Card
              className="border border-dashed flex items-center justify-center h-[100px] bg-muted/20 hover:bg-muted/40 transition-colors cursor-pointer"
              onClick={() => document.getElementById("add-income-trigger")?.click()}
            >
              <div className="flex flex-col items-center gap-2 text-muted-foreground">
                <PlusCircle className="h-8 w-8" />
                <p>Add Income Source</p>
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="expenses" className="space-y-4">
          {/* Expense Analytics */}
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Expenses by Category</CardTitle>
                <CardDescription>Breakdown of your daily expenses</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ExpenseByCategoryChart expenses={dailyExpenses} />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Your latest expenses</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {dailyExpenses.slice(0, 5).map((expense) => (
                    <div key={expense.id} className="flex items-center justify-between">
                      <div className="flex flex-col">
                        <span className="font-medium">{expense.title}</span>
                        <span className="text-xs text-muted-foreground">{expense.category}</span>
                      </div>
                      <div className="flex flex-col items-end">
                        <span className="font-medium">{expense.amount}</span>
                        <span className="text-xs text-muted-foreground">
                          {new Date(expense.date).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" size="sm" className="w-full" onClick={() => setActiveTab("expenses")}>
                  View All Expenses
                </Button>
              </CardFooter>
            </Card>
          </div>

          {/* Expense Tracking */}
          <Card>
            <CardHeader>
              <CardTitle>Expense Tracker</CardTitle>
              <CardDescription>Log and manage your daily expenses</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search expenses..."
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <select
                  className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                >
                  {expenseCategories.map((category) => (
                    <option key={category} value={category}>
                      {category === "all" ? "All Categories" : category}
                    </option>
                  ))}
                </select>
                <AddDailyExpenseForm onAddExpense={addDailyExpense} />
              </div>

              <div className="rounded-md border">
                <div className="grid grid-cols-12 gap-2 p-4 font-medium border-b">
                  <div className="col-span-5">Description</div>
                  <div className="col-span-2">Category</div>
                  <div className="col-span-2">Amount</div>
                  <div className="col-span-2">Date</div>
                  <div className="col-span-1"></div>
                </div>
                <div className="divide-y">
                  {filteredDailyExpenses.length > 0 ? (
                    filteredDailyExpenses.map((expense) => (
                      <div key={expense.id} className="grid grid-cols-12 gap-2 p-4 items-center">
                        <div className="col-span-5">
                          <div className="font-medium">{expense.title}</div>
                          {expense.notes && <div className="text-xs text-muted-foreground">{expense.notes}</div>}
                        </div>
                        <div className="col-span-2">
                          <Badge variant="outline">{expense.category}</Badge>
                        </div>
                        <div className="col-span-2 font-medium">{expense.amount}</div>
                        <div className="col-span-2 text-sm text-muted-foreground">
                          {format(new Date(expense.date), "dd MMM yyyy")}
                        </div>
                        <div className="col-span-1 flex justify-end">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-muted-foreground hover:text-destructive"
                            onClick={() => deleteDailyExpense(expense.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-8 text-center">
                      <Calendar className="mx-auto h-12 w-12 text-muted-foreground/30 mb-4" />
                      <h3 className="text-lg font-medium">No expenses found</h3>
                      <p className="text-muted-foreground">Start tracking your expenses to see them here.</p>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Hidden buttons for programmatic triggering */}
      <Button id="add-expense-trigger" className="hidden">
        Add Expense
      </Button>
      <Button id="add-income-trigger" className="hidden">
        Add Income
      </Button>
    </div>
  )
}
