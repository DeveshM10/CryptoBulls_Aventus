"use client"

import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Search,
  BookOpen,
  Video,
  FileText,
  Award,
  Filter,
  ChevronRight,
  Star,
  Clock,
  CheckCircle2,
  Play,
  Pause,
} from "lucide-react"
import { useNotification } from "@/components/ui/notification"

// Sample learning resources data
const learningResources = [
  {
    id: 1,
    title: "Understanding Credit Scores",
    type: "article",
    category: "Credit",
    difficulty: "Beginner",
    duration: "10 min read",
    image: "/placeholder.svg?height=200&width=300",
    completed: true,
    popular: true,
    content:
      "Credit scores are numerical representations of your creditworthiness. They range from 300 to 900 in India, with higher scores indicating better creditworthiness. Lenders use these scores to determine whether to approve loans and what interest rates to offer. Factors affecting your credit score include payment history, credit utilization, length of credit history, types of credit, and recent credit inquiries.",
    url: "https://www.bankbazaar.com/credit-score.html",
  },
  {
    id: 2,
    title: "Investing in Index Funds",
    type: "video",
    category: "Investing",
    difficulty: "Intermediate",
    duration: "15 min video",
    image: "/placeholder.svg?height=200&width=300",
    completed: false,
    popular: true,
    videoUrl: "https://www.youtube.com/embed/fwe-PjrX23o",
  },
  {
    id: 3,
    title: "Budgeting 101",
    type: "article",
    category: "Budgeting",
    difficulty: "Beginner",
    duration: "8 min read",
    image: "/placeholder.svg?height=200&width=300",
    completed: true,
    popular: false,
    content:
      "Budgeting is the process of creating a plan for how you will spend your money. It ensures that you have enough money for the things you need and the things that are important to you. Creating a budget requires tracking your income and expenses, categorizing your spending, and making adjustments to stay within your financial goals.",
    url: "https://www.nerdwallet.com/article/finance/how-to-budget",
  },
  {
    id: 4,
    title: "Debt Reduction Strategies",
    type: "quiz",
    category: "Debt",
    difficulty: "Intermediate",
    duration: "5 questions",
    image: "/placeholder.svg?height=200&width=300",
    completed: false,
    popular: false,
    questions: [
      {
        question: "Which debt repayment strategy focuses on paying off the smallest debts first?",
        options: ["Avalanche Method", "Snowball Method", "Consolidation Method", "Balance Transfer Method"],
        correctAnswer: "Snowball Method",
      },
      {
        question: "What is the primary benefit of the debt avalanche method?",
        options: [
          "Psychological wins",
          "Saves the most money in interest",
          "Improves credit score faster",
          "Reduces the number of creditors quickly",
        ],
        correctAnswer: "Saves the most money in interest",
      },
      {
        question: "Which of the following is NOT a common debt reduction strategy?",
        options: ["Debt consolidation", "Debt settlement", "Debt snowball", "Debt multiplication"],
        correctAnswer: "Debt multiplication",
      },
      {
        question: "What is a balance transfer in the context of debt reduction?",
        options: [
          "Moving debt from a high-interest credit card to a lower-interest one",
          "Paying off debt in equal monthly installments",
          "Negotiating with creditors to pay less than you owe",
          "Borrowing money from family to pay off debt",
        ],
        correctAnswer: "Moving debt from a high-interest credit card to a lower-interest one",
      },
      {
        question: "Which debt should you prioritize if using the avalanche method?",
        options: [
          "The smallest debt",
          "The debt with the highest interest rate",
          "The newest debt",
          "The debt with the lowest minimum payment",
        ],
        correctAnswer: "The debt with the highest interest rate",
      },
    ],
  },
  {
    id: 5,
    title: "Retirement Planning Essentials",
    type: "article",
    category: "Retirement",
    difficulty: "Advanced",
    duration: "12 min read",
    image: "/placeholder.svg?height=200&width=300",
    completed: false,
    popular: true,
    content:
      "Retirement planning involves determining retirement income goals and the actions necessary to achieve those goals. It includes identifying sources of income, estimating expenses, implementing a savings program, and managing assets and risk. Future cash flows are estimated to determine if the retirement income goal will be achieved.",
    url: "https://www.investopedia.com/terms/r/retirement-planning.asp",
  },
  {
    id: 6,
    title: "Understanding Mutual Funds",
    type: "video",
    category: "Investing",
    difficulty: "Intermediate",
    duration: "20 min video",
    image: "/placeholder.svg?height=200&width=300",
    completed: false,
    popular: false,
    videoUrl: "https://www.youtube.com/embed/xCpLxcyLRqk",
  },
  {
    id: 7,
    title: "Tax Optimization Strategies",
    type: "article",
    category: "Taxes",
    difficulty: "Advanced",
    duration: "15 min read",
    image: "/placeholder.svg?height=200&width=300",
    completed: false,
    popular: false,
    content:
      "Tax optimization involves legally reducing your tax burden through various strategies. These may include maximizing deductions and credits, timing income and expenses, using tax-advantaged accounts, and strategic investment planning. Understanding the tax code and working with tax professionals can help you develop effective tax optimization strategies.",
    url: "https://cleartax.in/s/tax-saving-investment",
  },
  {
    id: 8,
    title: "Emergency Fund Basics",
    type: "quiz",
    category: "Savings",
    difficulty: "Beginner",
    duration: "8 questions",
    image: "/placeholder.svg?height=200&width=300",
    completed: true,
    popular: true,
    questions: [
      {
        question: "How much should an ideal emergency fund cover?",
        options: ["1 month of expenses", "3-6 months of expenses", "1 year of expenses", "5 years of expenses"],
        correctAnswer: "3-6 months of expenses",
      },
      {
        question: "Where should you keep your emergency fund?",
        options: ["In stocks", "In a high-yield savings account", "In cryptocurrency", "Under your mattress"],
        correctAnswer: "In a high-yield savings account",
      },
      {
        question: "Which of the following is NOT a good use of emergency funds?",
        options: ["Medical emergencies", "Job loss", "Car repairs", "Vacation"],
        correctAnswer: "Vacation",
      },
      {
        question: "How often should you review and update your emergency fund?",
        options: ["Never", "Once a year", "Every 5 years", "Only when you use it"],
        correctAnswer: "Once a year",
      },
      {
        question: "What should you do after using your emergency fund?",
        options: [
          "Close the account",
          "Replenish it as soon as possible",
          "Reduce the target amount",
          "Switch to a different bank",
        ],
        correctAnswer: "Replenish it as soon as possible",
      },
      {
        question: "Which life event might require you to increase your emergency fund?",
        options: ["Getting a raise", "Paying off debt", "Having a child", "Moving in with roommates"],
        correctAnswer: "Having a child",
      },
      {
        question: "What is the first step in building an emergency fund?",
        options: [
          "Setting a target amount",
          "Opening a new bank account",
          "Cutting all discretionary spending",
          "Taking out a loan",
        ],
        correctAnswer: "Setting a target amount",
      },
      {
        question: "Which of these is a sign that your emergency fund is too large?",
        options: [
          "You have high-interest debt",
          "You're missing investment opportunities",
          "You're living paycheck to paycheck",
          "You recently had to use it",
        ],
        correctAnswer: "You're missing investment opportunities",
      },
    ],
  },
]

// Sample user progress data
const userProgress = {
  level: 3,
  xp: 450,
  nextLevelXp: 600,
  streak: 5,
  badges: [
    {
      id: 1,
      name: "First Steps",
      description: "Complete your first lesson",
      icon: <CheckCircle2 className="h-6 w-6" />,
    },
    { id: 2, name: "Knowledge Seeker", description: "Complete 5 lessons", icon: <BookOpen className="h-6 w-6" /> },
    { id: 3, name: "Streak Master", description: "Maintain a 5-day streak", icon: <Award className="h-6 w-6" /> },
  ],
  completedResources: 3,
  totalResources: learningResources.length,
}

export default function LearnPage() {
  // State for search and filters
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [selectedType, setSelectedType] = useState("All")
  const [selectedResource, setSelectedResource] = useState<any>(null)
  const [quizAnswers, setQuizAnswers] = useState<Record<number, string>>({})
  const [quizSubmitted, setQuizSubmitted] = useState(false)
  const [quizScore, setQuizScore] = useState(0)
  const [isVideoPlaying, setIsVideoPlaying] = useState(false)
  const videoRef = useRef<HTMLIFrameElement>(null)
  const { show } = useNotification()

  // Get unique categories from resources
  const categories = ["All", ...new Set(learningResources.map((resource) => resource.category))]

  // Filter resources based on search term and filters
  const filteredResources = learningResources.filter((resource) => {
    const matchesSearch = resource.title.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "All" || resource.category === selectedCategory
    const matchesType = selectedType === "All" || resource.type === selectedType

    return matchesSearch && matchesCategory && matchesType
  })

  const handleResourceSelect = (resource: any) => {
    setSelectedResource(resource)
    setQuizAnswers({})
    setQuizSubmitted(false)
    setQuizScore(0)

    // Award XP for starting a new resource
    if (!resource.completed) {
      show({
        title: "Learning Started",
        description: `You've started learning about ${resource.title}. Keep going!`,
        variant: "info",
      })
    }
  }

  const handleQuizAnswer = (questionIndex: number, answer: string) => {
    setQuizAnswers({
      ...quizAnswers,
      [questionIndex]: answer,
    })
  }

  const handleQuizSubmit = () => {
    if (!selectedResource || selectedResource.type !== "quiz") return

    let correctAnswers = 0
    selectedResource.questions.forEach((question: any, index: number) => {
      if (quizAnswers[index] === question.correctAnswer) {
        correctAnswers++
      }
    })

    const score = Math.round((correctAnswers / selectedResource.questions.length) * 100)
    setQuizScore(score)
    setQuizSubmitted(true)

    if (score >= 70) {
      show({
        title: "Quiz Completed!",
        description: `You scored ${score}% on the quiz. Great job!`,
        variant: "success",
      })
    } else {
      show({
        title: "Quiz Completed",
        description: `You scored ${score}% on the quiz. Try again to improve your score.`,
        variant: "info",
      })
    }
  }

  const handleCloseResource = () => {
    setSelectedResource(null)
  }

  const toggleVideoPlayback = () => {
    if (videoRef.current) {
      const iframe = videoRef.current
      const player = iframe.contentWindow

      if (isVideoPlaying) {
        player?.postMessage('{"event":"command","func":"pauseVideo","args":""}', "*")
      } else {
        player?.postMessage('{"event":"command","func":"playVideo","args":""}', "*")
      }

      setIsVideoPlaying(!isVideoPlaying)
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Learning Hub</h2>
          <p className="text-muted-foreground">Improve your financial literacy with articles, videos, and quizzes</p>
        </div>
      </div>

      {selectedResource ? (
        <Card className="mb-4">
          <CardHeader className="flex flex-row items-start justify-between">
            <div>
              <CardTitle>{selectedResource.title}</CardTitle>
              <div className="flex flex-wrap gap-2 mt-2">
                <Badge variant="outline">{selectedResource.category}</Badge>
                <Badge
                  variant="outline"
                  className={
                    selectedResource.difficulty === "Beginner"
                      ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
                      : selectedResource.difficulty === "Intermediate"
                        ? "bg-amber-500/10 text-amber-500 border-amber-500/20"
                        : "bg-rose-500/10 text-rose-500 border-rose-500/20"
                  }
                >
                  {selectedResource.difficulty}
                </Badge>
                <Badge variant="outline" className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {selectedResource.duration}
                </Badge>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={handleCloseResource}>
              Close
            </Button>
          </CardHeader>
          <CardContent>
            {selectedResource.type === "article" && (
              <div className="space-y-4">
                <div className="aspect-video w-full bg-muted rounded-lg overflow-hidden">
                  <img
                    src={selectedResource.image || "/placeholder.svg"}
                    alt={selectedResource.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="prose max-w-none dark:prose-invert">
                  <p>{selectedResource.content}</p>
                  <div className="mt-6">
                    <a
                      href={selectedResource.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:underline flex items-center"
                    >
                      Read full article
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </a>
                  </div>
                </div>
              </div>
            )}

            {selectedResource.type === "video" && (
              <div className="space-y-4">
                <div className="aspect-video w-full bg-muted rounded-lg overflow-hidden relative">
                  <iframe
                    ref={videoRef}
                    width="100%"
                    height="100%"
                    src={`${selectedResource.videoUrl}?enablejsapi=1`}
                    title={selectedResource.title}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                  <div className="absolute bottom-4 right-4">
                    <Button
                      variant="secondary"
                      size="sm"
                      className="bg-background/80 backdrop-blur-sm"
                      onClick={toggleVideoPlayback}
                    >
                      {isVideoPlaying ? (
                        <>
                          <Pause className="h-4 w-4 mr-2" />
                          Pause
                        </>
                      ) : (
                        <>
                          <Play className="h-4 w-4 mr-2" />
                          Play
                        </>
                      )}
                    </Button>
                  </div>
                </div>
                <div className="prose max-w-none dark:prose-invert">
                  <h3>Video Summary</h3>
                  <p>
                    This video explains key concepts about {selectedResource.title.toLowerCase()}. Watch the full video
                    to learn more about this important financial topic.
                  </p>
                </div>
              </div>
            )}

            {selectedResource.type === "quiz" && (
              <div className="space-y-6">
                <div className="prose max-w-none dark:prose-invert">
                  <p>Test your knowledge about {selectedResource.title.toLowerCase()} with this quiz.</p>
                </div>

                {quizSubmitted ? (
                  <div className="space-y-6">
                    <div className="p-4 rounded-lg bg-muted/50 text-center">
                      <h3 className="text-xl font-bold mb-2">Quiz Results</h3>
                      <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-primary/10 mb-4">
                        <span className="text-2xl font-bold text-primary">{quizScore}%</span>
                      </div>
                      <p className="text-muted-foreground">
                        {quizScore >= 70
                          ? "Great job! You've mastered this topic."
                          : "Keep learning and try again to improve your score."}
                      </p>
                    </div>

                    <div className="space-y-4">
                      {selectedResource.questions.map((question: any, index: number) => (
                        <div key={index} className="p-4 rounded-lg border">
                          <h4 className="font-medium mb-2">
                            {index + 1}. {question.question}
                          </h4>
                          <div className="space-y-2">
                            {question.options.map((option: string) => (
                              <div
                                key={option}
                                className={`p-3 rounded-md ${
                                  quizAnswers[index] === option
                                    ? option === question.correctAnswer
                                      ? "bg-emerald-500/10 border border-emerald-500/20"
                                      : "bg-rose-500/10 border border-rose-500/20"
                                    : option === question.correctAnswer
                                      ? "bg-emerald-500/10 border border-emerald-500/20"
                                      : "bg-muted/30"
                                }`}
                              >
                                <div className="flex items-center justify-between">
                                  <span>{option}</span>
                                  {option === question.correctAnswer && (
                                    <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>

                    <Button onClick={handleCloseResource} className="w-full">
                      Back to Learning Hub
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {selectedResource.questions.map((question: any, index: number) => (
                      <div key={index} className="p-4 rounded-lg border">
                        <h4 className="font-medium mb-2">
                          {index + 1}. {question.question}
                        </h4>
                        <div className="space-y-2">
                          {question.options.map((option: string) => (
                            <div
                              key={option}
                              className={`p-3 rounded-md cursor-pointer ${
                                quizAnswers[index] === option
                                  ? "bg-primary/10 border border-primary/20"
                                  : "bg-muted/30 hover:bg-muted/50"
                              }`}
                              onClick={() => handleQuizAnswer(index, option)}
                            >
                              {option}
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}

                    <Button
                      onClick={handleQuizSubmit}
                      className="w-full"
                      disabled={Object.keys(quizAnswers).length !== selectedResource.questions.length}
                    >
                      Submit Quiz
                    </Button>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="md:col-span-2">
              {/* Search and filters */}
              <Card className="mb-4">
                <CardContent className="pt-6">
                  <div className="flex flex-col md:flex-row gap-4">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search resources..."
                        className="pl-10"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                    <div className="flex gap-2">
                      <div>
                        <select
                          className="h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                          value={selectedCategory}
                          onChange={(e) => setSelectedCategory(e.target.value)}
                        >
                          {categories.map((category) => (
                            <option key={category} value={category}>
                              {category}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <select
                          className="h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                          value={selectedType}
                          onChange={(e) => setSelectedType(e.target.value)}
                        >
                          <option value="All">All Types</option>
                          <option value="article">Articles</option>
                          <option value="video">Videos</option>
                          <option value="quiz">Quizzes</option>
                        </select>
                      </div>
                      <Button variant="outline" size="icon">
                        <Filter className="h-4 w-4" />
                        <span className="sr-only">Filter</span>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Learning resources */}
              <Tabs defaultValue="all" className="space-y-4">
                <TabsList>
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="articles">Articles</TabsTrigger>
                  <TabsTrigger value="videos">Videos</TabsTrigger>
                  <TabsTrigger value="quizzes">Quizzes</TabsTrigger>
                  <TabsTrigger value="completed">Completed</TabsTrigger>
                </TabsList>

                <TabsContent value="all" className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    {filteredResources.length > 0 ? (
                      filteredResources.map((resource) => (
                        <ResourceCard
                          key={resource.id}
                          resource={resource}
                          onSelect={() => handleResourceSelect(resource)}
                        />
                      ))
                    ) : (
                      <div className="md:col-span-2 flex flex-col items-center justify-center py-12 text-center">
                        <Search className="h-12 w-12 text-muted-foreground/30 mb-4" />
                        <h3 className="text-lg font-medium">No resources found</h3>
                        <p className="text-muted-foreground">Try adjusting your search or filters</p>
                      </div>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="articles" className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    {filteredResources.filter((r) => r.type === "article").length > 0 ? (
                      filteredResources
                        .filter((r) => r.type === "article")
                        .map((resource) => (
                          <ResourceCard
                            key={resource.id}
                            resource={resource}
                            onSelect={() => handleResourceSelect(resource)}
                          />
                        ))
                    ) : (
                      <div className="md:col-span-2 flex flex-col items-center justify-center py-12 text-center">
                        <BookOpen className="h-12 w-12 text-muted-foreground/30 mb-4" />
                        <h3 className="text-lg font-medium">No articles found</h3>
                        <p className="text-muted-foreground">Try adjusting your search or filters</p>
                      </div>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="videos" className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    {filteredResources.filter((r) => r.type === "video").length > 0 ? (
                      filteredResources
                        .filter((r) => r.type === "video")
                        .map((resource) => (
                          <ResourceCard
                            key={resource.id}
                            resource={resource}
                            onSelect={() => handleResourceSelect(resource)}
                          />
                        ))
                    ) : (
                      <div className="md:col-span-2 flex flex-col items-center justify-center py-12 text-center">
                        <Video className="h-12 w-12 text-muted-foreground/30 mb-4" />
                        <h3 className="text-lg font-medium">No videos found</h3>
                        <p className="text-muted-foreground">Try adjusting your search or filters</p>
                      </div>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="quizzes" className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    {filteredResources.filter((r) => r.type === "quiz").length > 0 ? (
                      filteredResources
                        .filter((r) => r.type === "quiz")
                        .map((resource) => (
                          <ResourceCard
                            key={resource.id}
                            resource={resource}
                            onSelect={() => handleResourceSelect(resource)}
                          />
                        ))
                    ) : (
                      <div className="md:col-span-2 flex flex-col items-center justify-center py-12 text-center">
                        <FileText className="h-12 w-12 text-muted-foreground/30 mb-4" />
                        <h3 className="text-lg font-medium">No quizzes found</h3>
                        <p className="text-muted-foreground">Try adjusting your search or filters</p>
                      </div>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="completed" className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    {filteredResources.filter((r) => r.completed).length > 0 ? (
                      filteredResources
                        .filter((r) => r.completed)
                        .map((resource) => (
                          <ResourceCard
                            key={resource.id}
                            resource={resource}
                            onSelect={() => handleResourceSelect(resource)}
                          />
                        ))
                    ) : (
                      <div className="md:col-span-2 flex flex-col items-center justify-center py-12 text-center">
                        <CheckCircle2 className="h-12 w-12 text-muted-foreground/30 mb-4" />
                        <h3 className="text-lg font-medium">No completed resources</h3>
                        <p className="text-muted-foreground">Start learning to see your progress here</p>
                      </div>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            {/* User progress sidebar */}
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Your Progress</CardTitle>
                  <CardDescription>Track your learning journey</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Level {userProgress.level}</span>
                      <span className="text-sm text-muted-foreground">
                        {userProgress.xp}/{userProgress.nextLevelXp} XP
                      </span>
                    </div>
                    <Progress value={(userProgress.xp / userProgress.nextLevelXp) * 100} className="h-2" />
                  </div>

                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center">
                      <Award className="h-5 w-5 text-primary mr-2" />
                      <span className="font-medium">Current Streak</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-lg font-bold">{userProgress.streak}</span>
                      <span className="text-sm text-muted-foreground ml-1">days</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-medium">Completion</h3>
                    <div className="flex items-center gap-2">
                      <Progress
                        value={(userProgress.completedResources / userProgress.totalResources) * 100}
                        className="h-2 flex-1"
                      />
                      <span className="text-sm text-muted-foreground">
                        {userProgress.completedResources}/{userProgress.totalResources}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Your Badges</CardTitle>
                  <CardDescription>Achievements you've earned</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-2">
                    {userProgress.badges.map((badge) => (
                      <div key={badge.id} className="flex flex-col items-center text-center">
                        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-1 text-primary">
                          {badge.icon}
                        </div>
                        <span className="text-xs font-medium">{badge.name}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" size="sm" className="w-full">
                    View All Badges
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recommended</CardTitle>
                  <CardDescription>Based on your interests</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {learningResources
                    .filter((r) => r.popular && !r.completed)
                    .slice(0, 3)
                    .map((resource) => (
                      <div
                        key={resource.id}
                        className="flex items-start gap-3 cursor-pointer hover:bg-muted/50 p-2 rounded-md transition-colors"
                        onClick={() => handleResourceSelect(resource)}
                      >
                        <div className="w-12 h-12 rounded bg-muted flex-shrink-0 overflow-hidden">
                          <img
                            src={resource.image || "/placeholder.svg"}
                            alt={resource.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">{resource.title}</h4>
                          <p className="text-xs text-muted-foreground">{resource.duration}</p>
                        </div>
                      </div>
                    ))}
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" size="sm" className="w-full">
                    View More
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </>
      )}
    </div>
  )
}

// Resource card component
function ResourceCard({ resource, onSelect }: { resource: any; onSelect: () => void }) {
  // Helper function to get icon based on resource type
  const getTypeIcon = (type: string) => {
    switch (type) {
      case "article":
        return <BookOpen className="h-4 w-4" />
      case "video":
        return <Video className="h-4 w-4" />
      case "quiz":
        return <FileText className="h-4 w-4" />
      default:
        return <BookOpen className="h-4 w-4" />
    }
  }

  // Helper function to get badge color based on difficulty
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner":
        return "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
      case "Intermediate":
        return "bg-amber-500/10 text-amber-500 border-amber-500/20"
      case "Advanced":
        return "bg-rose-500/10 text-rose-500 border-rose-500/20"
      default:
        return "bg-primary/10 text-primary border-primary/20"
    }
  }

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer" onClick={onSelect}>
      <div className="relative h-40 w-full overflow-hidden">
        <img
          src={resource.image || "/placeholder.svg"}
          alt={resource.title}
          className="w-full h-full object-cover transition-transform hover:scale-105"
        />
        {resource.completed && (
          <div className="absolute top-2 right-2 bg-emerald-500 text-white text-xs font-medium px-2 py-1 rounded-full flex items-center">
            <CheckCircle2 className="h-3 w-3 mr-1" />
            Completed
          </div>
        )}
        {resource.popular && !resource.completed && (
          <div className="absolute top-2 right-2 bg-primary text-primary-foreground text-xs font-medium px-2 py-1 rounded-full flex items-center">
            <Star className="h-3 w-3 mr-1" />
            Popular
          </div>
        )}
      </div>
      <CardContent className="p-4">
        <div className="flex flex-wrap gap-2 mb-2">
          <Badge variant="outline" className="flex items-center gap-1 text-xs">
            {getTypeIcon(resource.type)}
            {resource.type.charAt(0).toUpperCase() + resource.type.slice(1)}
          </Badge>
          <Badge variant="outline" className="text-xs">
            {resource.category}
          </Badge>
          <Badge variant="outline" className={`text-xs ${getDifficultyColor(resource.difficulty)}`}>
            {resource.difficulty}
          </Badge>
        </div>
        <h3 className="font-medium mb-1">{resource.title}</h3>
        <div className="flex items-center text-xs text-muted-foreground mb-4">
          <Clock className="h-3 w-3 mr-1" />
          {resource.duration}
        </div>
        <Button size="sm" className="w-full">
          {resource.completed ? "Review Again" : "Start Learning"}
          <ChevronRight className="h-4 w-4 ml-1" />
        </Button>
      </CardContent>
    </Card>
  )
}
